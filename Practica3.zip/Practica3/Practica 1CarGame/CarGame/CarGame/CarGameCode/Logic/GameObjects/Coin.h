#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "GameObject.h"
#include "GoodObject.h"

using namespace std;

class Game;

class Coin : public GoodObject {
private:
	int numC = 10;
	int PUEnJuego();

public:
	bool pasado = false;

	Coin(Game* game);
	~Coin();
	void draw();
	void update();
	void setPosition();
	void setDimension(int width, int height);
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	bool receiveCarCollision(Car* car) override;

};

