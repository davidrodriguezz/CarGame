#include "AccCommand.h"

bool AccCommand::parse(SDL_Event& event) {
	if (event.type == SDL_KEYDOWN) {
		SDL_Keycode key = event.key.keysym.sym;
		if (key == SDLK_RIGHT) {
			 arriba = true;
			return true;
		}
		else if (key == SDLK_LEFT) {
			arriba = false;
			return true;
		}
	}
	return false;
}

void AccCommand::execute() {
	if (arriba) {
		game->Accelerate();
	}
	else game->Brake();
}