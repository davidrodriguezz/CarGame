#include "Wall.h"
#include <iostream>
#include <time.h>
#include "../Game.h"



Wall::Wall(Game* game):BadObject(game) {
	w = ROCK_WIDTH;
	h = ROCK_HEIGHT;

}

Wall::~Wall() {
}

void Wall::update() {
}

void Wall::draw() {
	drawTexture(game->getTexture(rockTexture));
}

void Wall::drawTexture(Texture* texture) {
	int dX = game->getOrigin().getX();
	int dY = game->getOrigin().getY();

	SDL_Rect c = getCollider();
	SDL_Rect textureBox = { c.x + dX, c.y + dY, c.w, c.h };
	texture->render(textureBox);
}

SDL_Rect Wall::getCollider() {
	return { int(getX() - getWidth()),
			 int(getY() - getHeight() / 2),
			 getWidth(),
			 getHeight() };
}

bool Wall::receiveCarCollision(Car* car) {
	car->lessLive();
	car->setNullVel();
	return true;
}

bool Wall::receiveBulletCollision(Bullet* bullet){
	
	return true;
}