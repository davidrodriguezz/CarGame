//
// Created by eys on 20/8/21.
//

#ifndef CARGAME_GAME_H
#define CARGAME_GAME_H

#include <iostream>
#include <string>
#include <vector>

#include "../View/TextureContainer.h"
#include "../View/Texture.h"
#include "../View/Box.h"
#include "../View/Font.h"

#include "GameObjects/Car.h"
#include "GameObjects/Wall.h"
#include "GameObjectContainer.h"
#include "GameObjects/PowerUp.h"
#include "GameObjects/SuperRock.h"
#include "GameObjects/Truck.h"
#include "GameObjects/Oil.h"
#include "GameObjects/Coin.h"
#include "GameObjects/Turbo.h"
#include "GameObjects/Bullet.h"
#include "../View/Infobar.h"
using namespace std;

class Game{
private:
    string name;
    bool doExit;
    int roadLength;
    int width, height;
    Car *car = nullptr;   
    TextureContainer *textureContainer;
    SDL_Renderer* renderer = nullptr;
    Font *font;
	int tiempo;
	int timerTurbo;
	int numpiedras = 5;
	int npowerUps = 5;
	int nsuperRocks = 5;
	int nTrucks = 5;
	int nOils = 5;
	int nCoins = 5;
	int nTurbos = 5;

    int wf, hf;
    Texture* texturaF;

	const unsigned int CAR_WIDTH = 100;
	const unsigned  int CAR_HEIGHT = 50;


	const unsigned int GOAL_WIDTH = 20;
	const unsigned  int GOAL_HEIGHT = 350;
    
    Point2D<double> posF;
    friend class Infobar;
	Infobar* information;
	bool win;
public:
    enum Estado { menu, playing, gameOver } estado;
    GameObjectContainer* goc = nullptr;

    Game(string name, int width, int height, int roadLength);
    ~Game();

    void startGame();
    void update();
    void draw();

    void setUserExit();
    bool isUserExit();
    bool doQuit();

    int getWindowWidth();
    int getWindowHeight();

    Point2D<int> getOrigin();

    string getGameName();

    void setRenderer(SDL_Renderer *renderer);
    void loadTextures();
    Texture *getTexture(TextureName name);
    SDL_Renderer *getRenderer();
    void renderText(string text, int x, int y, SDL_Color color={0,0,0});

    void drawInfo(int time);
    void drawMenuInfo();
    void drawGameOverInfo();
    void drawGameOverInfo2(int tiempo);

    void setCarUp();
    void setCarDown();
    void Accelerate();
    void Brake();
	int getTiempo() {			//obtiene el tiempo guardado del juego
		return tiempo;
	}

    bool isOutOfGame(GameObject* obj);

    void drawFinishLine();
    void setFinishPosition();
    void setFinishDimension(int width, int height);
    SDL_Rect getFinishCollider();
    void drawFinishTexture(Texture* texture);
   
    void CambiaEstado();
    void SetInitialState();
    void SetGameOverState();
    void drawState();

    bool buy(int coin);
    void setInitCoins();
	void reduceSpeed(float r);
	int getTimerTurbo() {
		return timerTurbo;
	}
	void setTimerTurbo(int x) {
		timerTurbo = x;
	}
	void lessTimerTurbo(int x) {
		timerTurbo -= x;
	}

    vector<Collider*> getAllColliders() {
        return goc->getColliders();
    }
    
    void createBullet();
    void deleteBullet(GameObject* bullet);
	Estado getState() {
		return estado;
	}
};


#endif //CARGAME_GAME_H
