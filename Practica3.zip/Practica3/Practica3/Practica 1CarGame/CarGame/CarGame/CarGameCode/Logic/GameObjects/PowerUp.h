#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "GameObject.h"
#include "GoodObject.h"

using namespace std;

class Game;

class PowerUp : public GoodObject {
private:
	const unsigned int PU_WIDTH = 40;
	const unsigned  int PU_HEIGHT = 40;
public:
	PowerUp(Game* game);
	~PowerUp();
	void draw();
	void update();
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	bool receiveCarCollision(Car* car) override;
};

