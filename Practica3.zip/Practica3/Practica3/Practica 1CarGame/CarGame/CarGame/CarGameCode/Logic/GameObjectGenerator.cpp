#include <iostream>
#include "GameObjectGenerator.h"




Point2D<int> GameObjectGenerator::generateRandomPosition(Game* game, GameObject* o) {
	Point2D<int> posP;
	int posPiedraX = rand() % 5000+100;
	int posPiedraY = rand() % 280 + 40;
	posP = Point2D<int>(posPiedraX, posPiedraY);
	return  posP;
}


void GameObjectGenerator::addInRandomPosition(Game* game, GameObject* o,GameObjectContainer* goc) {
        o->setDimension(o->getWidth(), o->getHeight());
        o->setPosition(generateRandomPosition(game,o).getX(),generateRandomPosition(game,o).getY());
        
        bool solapa = false;

        if (goc->hasCollision(o)) {
            solapa = true;
        }
            
        if (!solapa) {
            goc->add(o);
        }
        else delete o;
}