#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "GameObject.h"
#include "BadObject.h"
class SuperRock : public BadObject
{
private:
	const unsigned int SUPERROCK_WIDTH = 120;
	const unsigned  int SUPERROCK_HEIGHT = 60;

	public:
		SuperRock(Game* game);
		~SuperRock();
		void draw();
		void update();
		SDL_Rect getCollider();
		void drawTexture(Texture* texture);
		bool receiveCarCollision(Car* car) override;
		bool receiveBulletCollision(Bullet* bullet) override;
};

