#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "../../Logic/GameObjects/Bullet.h"
#include "GameObject.h"
#include "BadObject.h"
//#include "../Game.h"

using namespace std;



class Wall : public BadObject{
private:
	const unsigned int ROCK_WIDTH = 50;
	const unsigned  int ROCK_HEIGHT = 50;
public:

	Wall(Game* game);
	~Wall();
	void draw();
	void update();
	void setPosition();
	void setDimension(int width, int height);
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	bool receiveCarCollision(Car* car) override;
	bool receiveBulletCollision(Bullet* bullet) override;
};