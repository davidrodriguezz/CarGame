#include <iostream>
#include "Bullet.h"
#include "../Game.h"
using namespace std;


Bullet::Bullet(Game* game,double x,double y):GameObject(game){
	w = BULLET_WIDTH;
	h = BULLET_HEIGHT;
	iniX = x;
	iniY = y;
	pos = { iniX,iniY };
}

Bullet::~Bullet() {

}

void Bullet::update() {
	if (alive) {
		moveFoward();
		if (pos.getX() - iniX > 700) {
			alive = !alive;
		}
		for (int i = 0; i < game->goc->GetSize(); i++)
			if (SDL_HasIntersection(&game->goc->GetObject(i)->getCollider(), &this->getCollider())) {
				if (game->goc->GetObject(i)->receiveBulletCollision(this)) {
					game->goc->removeDead(i);
					alive = !alive;
				}
			}
	}
	else game->deleteBullet(this);
}

void Bullet::moveFoward(){
	this->pos = { pos.getX() + 15, pos.getY() };
}

void Bullet::draw() {
	drawTexture(game->getTexture(bulletTexture));
}

void Bullet::drawTexture(Texture* texture) {
	int dX = game->getOrigin().getX();
	int dY = game->getOrigin().getY();

	SDL_Rect c = getCollider();
	SDL_Rect textureBox = { c.x + dX, c.y + dY, c.w, c.h };
	texture->render(textureBox);
}

SDL_Rect Bullet::getCollider() {
	return { int(getX() - getWidth()),
			 int(getY() - getHeight() / 2),
			 getWidth(),
			 getHeight() };
}

