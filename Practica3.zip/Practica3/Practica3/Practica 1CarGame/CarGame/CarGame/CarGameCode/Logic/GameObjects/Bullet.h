#pragma once
#include <iostream>
#include "GameObject.h"

class Bullet : public GameObject
{
public:
	Bullet(Game* game,double iniX,double iniY);
	~Bullet();
	
	bool alive = true;

	
	void draw();
	void update();
	
	
	void setDimension(int width, int height);
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	void moveFoward();
	Point2D<double>* initPos;

private:
	const int BULLET_WIDTH=20;
	const int BULLET_HEIGHT=5;
	double iniX, iniY;

};

