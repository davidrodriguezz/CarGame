#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "GameObject.h"
#include "BadObject.h"
class Oil : public BadObject
{
private:
	const unsigned int OIL_WIDTH = 40;
	const unsigned  int OIL_HEIGHT = 40;

public:
	Oil(Game* game);
	~Oil();
	void draw();
	void update();
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	bool receiveCarCollision(Car* car) override;
};

