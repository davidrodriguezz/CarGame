#pragma once
#include <iostream>
#include "../../Utils/Vector2D.h"
#include "../../View/Texture.h"
#include "../../View/Box.h"
#include "../../Logic/GameObjects/Car.h"
#include "GameObject.h"
#include "GoodObject.h"
class Turbo : public GoodObject
{
private:
	const unsigned int TURBO_WIDTH = 70;
	const unsigned  int TURBO_HEIGHT = 40;

public:
	bool pasado = false;

	Turbo(Game* game);
	~Turbo();
	void draw();
	void update();
	SDL_Rect getCollider();
	void drawTexture(Texture* texture);
	bool receiveCarCollision(Car* car) override;
};



