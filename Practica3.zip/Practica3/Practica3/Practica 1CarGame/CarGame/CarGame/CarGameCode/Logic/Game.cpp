//
// Created by eys on 20/8/21.
//

#include "Game.h"
#include "GameObjectGenerator.h"
#include <time.h>
Game::Game(string name, int width, int height, int roadLength) {
    this->name = name;
    this->roadLength = roadLength;
    this->width = width;
    this->height = height;
    doExit = false;
    font = new Font("../Images/Monospace.ttf", 12);
	information = new Infobar(this);
}


void Game::startGame() {
    srand(time(NULL));
	tiempo = SDL_GetTicks();
    car = new Car(this);
    car->setDimension(CAR_WIDTH, CAR_HEIGHT);
    car->setPosition(car->getWidth(), height/ 2.0);
	GoodObject::reset();
	BadObject::reset();
    goc = new GameObjectContainer();
    GameObjectGenerator::generate(this,goc,numpiedras,npowerUps,nsuperRocks,nOils,nTurbos,nCoins,nTrucks);
    
    setFinishPosition();
    setFinishDimension(GOAL_WIDTH, GOAL_HEIGHT);
}

string Game::getGameName() {
    return name;
}

Game::~Game() {
    cout << "[DEBUG] deleting game" << endl;
	delete car;
    car = nullptr;
    delete font;
    font = nullptr;
    delete textureContainer;
    textureContainer = nullptr;
    delete goc;
    goc = nullptr;
	delete information;
	information = nullptr;

}

void Game::update(){
    if (car != nullptr) {
        car->update();
    }
	if (goc != nullptr) {
		goc->update();				//llama al update de cada objeto
		for (int i = 0; i < goc->GetSize(); i++) {
			if (isOutOfGame(goc->GetObject(i))) {				//borra los objetos superados por el coche
				goc->removeDead(i);
			}
			else if (SDL_HasIntersection(&goc->GetObject(i)->getCollider(), &car->getCollider())) {			//si chocamos con un objeto comprueba que hacer
				if (goc->GetObject(i)->receiveCarCollision(car)) goc->removeDead(i);
			}
		}
	}
    if (SDL_HasIntersection(&getFinishCollider(), &car->getCollider())) {		//si chocamos con la l�nea de meta ganamos
		win = true;
		delete goc;
		goc = nullptr;
		delete car;
		car = nullptr;
		this->SetGameOverState();
		tiempo = SDL_GetTicks() - tiempo;

    }
	else if (car->getLives() <= 0) {				//si el jugador llega a la meta o pierde todas las vidas, destruye todas las entitades
		win = false;
		delete goc;
		goc = nullptr;
        delete car;
        car = nullptr;
		this->SetGameOverState();
	}
}

void Game::draw() {				//dibuja cada una de las entidades del juego, meduante c�digo defensivo
    if (car != nullptr) {
        car->draw();
    }
	if (goc!=nullptr) goc->draw();
	if (car != nullptr) {
		drawFinishLine();
	}

	if (estado == menu) {
		information->drawMenuInfo();
		information->drawState();
	}
	else if (estado == playing) {
		if (car != nullptr) {
			information->drawInfo();
			information->drawState();
		}
	}
	else if (estado == gameOver) {
		if (win) {
			information->drawGameOverInfo2();
			information->drawState();
		}
		else {
			information->drawGameOverInfo();
			information->drawState();
		}

	}
}

void Game::setUserExit() {
    doExit = true;
}

bool Game::isUserExit() {
    return doExit;
}

int Game::getWindowWidth(){
    return width;
}

int Game::getWindowHeight() {
    return height;
}

SDL_Renderer *Game::getRenderer() {
    return renderer;
}

void Game::setRenderer(SDL_Renderer *_renderer) {
    renderer = _renderer;
}

void Game::loadTextures() {
    if(renderer == nullptr)
        throw string("Renderer is null");

    textureContainer = new TextureContainer(renderer);
}

void Game::renderText(string text, int x, int y, SDL_Color color){
    font->render(renderer, text.c_str(), x, y, color);
}

bool Game::doQuit() {
    return isUserExit();
}

Texture *Game::getTexture(TextureName name) {
    return textureContainer->getTexture(name);
}

Point2D<int> Game::getOrigin() {
    return {int(-(car->getX() - car->getWidth())), 0};
}

void Game::setCarUp() {				//sube el coche
    car->setCarUp();
}

void Game::setCarDown() {				//baja el coche
    car->setCarDown();
}

void Game::Accelerate() {					//acelera el coche
    car->Accelerate();
}


void Game::Brake() {				//frena el coche
    car->Brake();
}

void Game::drawFinishLine() {				//dibuja la l�nea de meta
    drawFinishTexture(getTexture(goalTexture));
}

void Game::setFinishPosition() {
    int posFinalX = 5000;
    int posFinalY = getWindowHeight()/2;
    posF = Point2D<double>(posFinalX, posFinalY);
}

void Game::setFinishDimension(int width, int height) {
    wf = width;
    hf = height;
}



void Game::drawFinishTexture(Texture* texture) {
    
    int dX = getOrigin().getX();
    int dY = getOrigin().getY();
    
    SDL_Rect c = getFinishCollider();
    SDL_Rect textureBox = { c.x + dX, c.y + dY, c.w, c.h };
    texture->render(textureBox);
}

SDL_Rect Game::getFinishCollider() {
    return { int(posF.getX() - wf),
             int(posF.getY() - hf/2),
             wf,
             hf };
}

bool Game::isOutOfGame(GameObject* obj) {
    
    return obj != nullptr && obj->pos.getX() <= car->pos.getX() - car->getWidth() / 2;
    
}
void Game::CambiaEstado() {
    if (estado == menu) {
        estado = playing;
    }
    else if (estado == gameOver) {
        estado = menu;
    }
}
void Game::SetInitialState() {
    estado = menu;
}

void Game::SetGameOverState() {
    estado = gameOver;
}

void Game::drawState() {
    
        int x = font->getSize() / 2;
        int y = font->getSize() / 2;
        int n = 0;
        int i = 0;

    SDL_Rect rect = { 10, 315, getWindowWidth(),
                     int(font->getSize() * 1.8) };

    string s = "State: " + estado;
    renderText(s, x, y);
}

bool Game::buy(int cost) {
    if (car->getCoins() >= cost) {
        car->setCoins(-cost);
        return true;
    }
    else
        return false;
}

void Game::setInitCoins()
{
    car->setInitCoins();
}

void Game::reduceSpeed(float r)
{
	car->reduceSpeed(r);
}

void Game::createBullet() {
    goc->add(new Bullet(this,car->pos.getX(),car->pos.getY()));
}

void Game::deleteBullet(GameObject* bullet) {
    if (bullet != nullptr) {
        int i = 0;
        while (i < goc->GetSize()-1 && bullet != goc->GetObject(i)) {
            i++;
        }
        goc->removeDead(i);
    }
}

