#include "Infobar.h"

void Infobar::drawInfo()
{
	int x = game->font->getSize() / 2;
	int y = game->font->getSize() / 2;
	SDL_Rect rect = { 0, 0, game->getWindowWidth(),
				 int(game->font->getSize() * 1.8) };
	Box(rect, BLACK).render(game->renderer);
	string s[] = {
		"Pos: " + to_string(int(game->car->getX())) + " " + to_string(int(game->car->getY())),
		"Distance: " + to_string(int(game->roadLength - game->car->getX())),
		"Speed: " + to_string(int(game->car->getVel())),
		"Power: " + to_string(int(game->car->getLives())),
		"Timer: " + to_string(int(SDL_GetTicks() - game->tiempo)),
		"Objs: [" + to_string(int(GoodObject::instances)) + ", " + to_string(int(BadObject::instances)) + "]",
		"Coins: " + to_string(int(game->car->getCoins()))
	};
	for (auto a : s) {
		game->renderText(a, x, y, BLACK);
		x += 120;
	}
}

void Infobar::drawMenuInfo()
{
	int x = game->getWindowWidth() / 2-100;
	int y = game->getWindowHeight() / 3;
	string s[] = {
		"Welcome to Super Cars",
		"Level: 0",
		"Press space to start"
	};
	for (auto a : s) {
		game->renderText(a, x, y, BLACK);
		y += 20;
	}
}

void Infobar::drawGameOverInfo()
{
	int x = game->getWindowWidth() / 2-50;
	int y = game->getWindowHeight() / 3;
	int n = 1;

	string s = "GameOver";
	game->renderText(s, x, y, BLACK);
	
}

void Infobar::drawGameOverInfo2()
{
	int x = game->getWindowWidth() / 2 - 50;
	int y = game->getWindowHeight() / 3;
	string s[] = {
		"Congratulations!",
		"User wins",
		"Time: " + to_string(game->tiempo) + " ms"
	};
	for (auto a : s) {
		game->renderText(a, x, y, BLACK);
		y += 20;
	}
}

void Infobar::drawState()
{
	int x =10;
	int y = game->getWindowHeight()-20;
	string s;
	if (game->estado == 0) {
		s = "State: Menu";
	}
	else if (game->estado == 1) {
		s = "State: Playing";
	}
	else {
		s = "State: GameOver";
	}
	game->renderText(s, x, y, BLACK);
}


