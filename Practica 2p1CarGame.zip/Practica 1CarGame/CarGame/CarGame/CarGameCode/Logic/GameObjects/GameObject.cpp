#include <iostream>
#include "GameObject.h"


GameObject::GameObject(Game* game) {
	
}

void GameObject::setPosition(double x, double y)
{
    pos = Point2D<double>(x, y);
}
void GameObject::setDimension(double width, double height){
    w = width;
    h = height;
}

SDL_Rect GameObject::getCollider() {
	return { int(getX() - getWidth()),
			 int(getY() - getHeight() / 2),
			 getWidth(),
			 getHeight() 
	};
}

SDL_Rect GameObject::getCenter() {
	return { int(getX() + getWidth()/2),
			 int(getY() + getHeight() / 2),
			 getWidth()-getWidth()/2,
			 getHeight()-getHeight()/2
	};
}

bool GameObject::collide(SDL_Rect other) {
	return SDL_HasIntersection(&this->getCollider(), &other);
}