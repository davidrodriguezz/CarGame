#include <iostream>
#include "GameObjectContainer.h"

using namespace std;


void GameObjectContainer::removeDead() {

	delete gameObjects[];
	gameObjects.erase(obstacles.begin()+i);
}