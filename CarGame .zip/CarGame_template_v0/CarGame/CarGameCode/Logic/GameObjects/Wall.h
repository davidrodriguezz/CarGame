#pragma once
#include <iostream>

using namespace std;

class Wall {
private:
	int numPiedras = 20;
	int posPiedraX;
	int posPiedraY;
	//metodo para spawnear las piedras
	//metodo para quitar vidas
	//metodo que cuente las piedras (segun la forma de spawnear la piedras)
};